Unpack the zip file with the Binary Matrix Solution Generator.jar
and Binary Matrix Solution Generator_lib folder in the same place.
The program will not work otherwise.

Enjoy :)
Kishan Patel